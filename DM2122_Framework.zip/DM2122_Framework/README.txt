README FOR INFOMATION ABOUT THE PROGRAM
ADMIN NO: 160284B
NAME: Jolyn Wong Kaiyi

Camera movement: 
Mouse movement - control the pitch and yaw
W - Move forward
S - Move backwards
A - Strafe left
D - Strafe right
Right mouse button - Move faster

Interactions:
Near flower in igloo - press e to change to daytime
		     - press x to change to nighttime
Near tree - hold e to shake
Near snowball - click to pick up
Near flag - press e to raise flag
Near Chopper - press left mouse button to talk

Light:
Near Sun (Daytime) - directional light to be sunlight
Near Moon (Nighttime) - directional light to be moonlight
Near flower - point light to highlight flower

Reset:
Q - reset scene